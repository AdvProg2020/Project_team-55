package model;


import javafx.scene.control.Alert;
import javafx.scene.effect.Glow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.util.Pair;
import model.menu.GameMenu;
import sample.Main;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;

public class Cell {
    private static boolean sarbaz1Siah = true;
    Pieces pieces;
    int x;
    int y;
    Rectangle rectangle;
    ImageView imageView;
    Boolean empty;




    public static void assignCells(Cell[][] cell) throws FileNotFoundException {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                cell[i][j].pieces = Pieces.khali;
            }
        }

        Glow glow = new Glow(0.6);

        cell[7][0].pieces = Pieces.rokhSefid;
        cell[7][0].imageView.setImage(new Image(new FileInputStream("C:\\Users\\Asus\\IdeaProjects\\shatranj\\src\\model\\White_Rook.png")));
        cell[7][0].imageView.setEffect(glow);

        cell[7][1].pieces = Pieces.asbSefid;
        cell[7][1].imageView.setImage(new Image(new FileInputStream("C:\\Users\\Asus\\IdeaProjects\\shatranj\\src\\model\\White_Knight.png")));
        cell[7][1].imageView.setEffect(glow);

        cell[7][2].pieces = Pieces.fillSefid;
        cell[7][2].imageView.setImage(new Image(new FileInputStream("C:\\Users\\Asus\\IdeaProjects\\shatranj\\src\\model\\White_Bishop.png")));
        cell[7][2].imageView.setEffect(glow);

        cell[7][3].pieces = Pieces.vazirSefid;
        cell[7][3].imageView.setImage(new Image(new FileInputStream("C:\\Users\\Asus\\IdeaProjects\\shatranj\\src\\model\\White_Queen.png")));
        cell[7][3].imageView.setEffect(glow);

        cell[7][4].pieces = Pieces.shahSefid;
        cell[7][4].imageView.setImage(new Image(new FileInputStream("C:\\Users\\Asus\\IdeaProjects\\shatranj\\src\\model\\menu\\White_King.png")));
        cell[7][4].imageView.setEffect(glow);

        cell[7][5].pieces = Pieces.fillSefid;
        cell[7][5].imageView.setImage(new Image(new FileInputStream("C:\\Users\\Asus\\IdeaProjects\\shatranj\\src\\model\\White_Bishop.png")));
        cell[7][5].imageView.setEffect(glow);

        cell[7][6].pieces = Pieces.asbSefid;
        cell[7][6].imageView.setImage(new Image(new FileInputStream("C:\\Users\\Asus\\IdeaProjects\\shatranj\\src\\model\\White_Knight.png")));
        cell[7][6].imageView.setEffect(glow);

        cell[7][7].pieces = Pieces.rokhSefid;
        cell[7][7].imageView.setImage(new Image(new FileInputStream("C:\\Users\\Asus\\IdeaProjects\\shatranj\\src\\model\\White_Rook.png")));
        cell[7][7].imageView.setEffect(glow);

        for (int i = 0; i <= 7; i++) {
            cell[6][i].pieces = Pieces.sarbazSefid;
            cell[6][i].imageView.setImage(new Image(new FileInputStream("C:\\Users\\Asus\\IdeaProjects\\shatranj\\src\\model\\White_Pawn.png")));
            cell[6][i].imageView.setEffect(glow);

        }

        cell[0][0].pieces = Pieces.rokhSiah;
        cell[0][0].imageView.setImage(new Image(new FileInputStream("C:\\Users\\Asus\\IdeaProjects\\shatranj\\src\\model\\Black_Rook.png")));
        cell[0][0].imageView.setEffect(glow);

        cell[0][1].pieces = Pieces.asbSiah;
        cell[0][1].imageView.setImage(new Image(new FileInputStream("C:\\Users\\Asus\\IdeaProjects\\shatranj\\src\\model\\Black_Knight.png")));
        cell[0][1].imageView.setEffect(glow);
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        cell[0][2].pieces = Pieces.fillSiah;
        cell[0][2].imageView.setImage(new Image(new FileInputStream("C:\\Users\\Asus\\IdeaProjects\\shatranj\\src\\model\\Black_Bishop.png")));
        cell[0][2].imageView.setEffect(glow);

        cell[0][3].pieces = Pieces.vazirSiah;
        cell[0][3].imageView.setImage(new Image(new FileInputStream("C:\\Users\\Asus\\IdeaProjects\\shatranj\\src\\model\\Black_Queen.png")));
        cell[0][3].imageView.setEffect(glow);

        cell[0][4].pieces = Pieces.shahSiah;
        cell[0][4].imageView.setImage(new Image(new FileInputStream("C:\\Users\\Asus\\IdeaProjects\\shatranj\\src\\model\\Black_King.png")));
        cell[0][4].imageView.setEffect(glow);

        cell[0][5].pieces = Pieces.fillSiah;
        cell[0][5].imageView.setImage(new Image(new FileInputStream("C:\\Users\\Asus\\IdeaProjects\\shatranj\\src\\model\\Black_Bishop.png")));
        cell[0][5].imageView.setEffect(glow);

        cell[0][6].pieces = Pieces.asbSiah;
        cell[0][6].imageView.setImage(new Image(new FileInputStream("C:\\Users\\Asus\\IdeaProjects\\shatranj\\src\\model\\Black_Knight.png")));
        cell[0][6].imageView.setEffect(glow);

        cell[0][7].pieces = Pieces.rokhSiah;
        cell[0][7].imageView.setImage(new Image(new FileInputStream("C:\\Users\\Asus\\IdeaProjects\\shatranj\\src\\model\\Black_Rook.png")));
        cell[0][7].imageView.setEffect(glow);

        for (int i = 0; i < 8; i++) {
            cell[1][i].pieces = Pieces.sarbazSiah;

            cell[1][i].imageView.setImage(new Image(new FileInputStream("C:\\Users\\Asus\\IdeaProjects\\shatranj\\src\\model\\Black_Pawn.png")));
            cell[1][i].imageView.setEffect(glow);

        }
    }



    public Rectangle getRectangle() {
        return rectangle;
    }

    public Cell(int x, int y, Color color) {
        this.x = x;
        this.y = y;
        rectangle = new Rectangle(50, 50, color);
        empty = true;
    }

    public static void handleEventForThisCell(int x, int y) {
        if (Main.gameMenu.getSelected()) {

            for(Pair pair: Main.gameMenu.getValidCells()){
                if(pair.getKey().equals(Integer.valueOf(x)) && pair.getValue().equals(Integer.valueOf(y))){

                    //if red : sharte zadan bayad anjam shavad
                    //if Cyan : sharte harekat mitavand anja shavad
                    Cell selected = Main.gameMenu.getSelectedCell();
                    //if(x!=selected.x && y!=selected.y ) {


                        Main.gameMenu.setSelected(false);
                        Main.gameMenu.setSelectedCell(null);
                        Main.gameMenu.getCell(x, y).pieces = selected.pieces;
                        Main.gameMenu.getCell(selected.x, selected.y).pieces = Pieces.khali;
                        Main.gameMenu.getCell(x, y).imageView.setImage(selected.imageView.getImage());
                        Main.gameMenu.getCell(selected.x, selected.y).imageView.setImage(null);
                        Main.gameMenu.setValidCells(new ArrayList<>());
                        Main.gameMenu.setValidCells(new ArrayList<>());
                        retunToHAlatAvalie();
                    if(selected.pieces == Pieces.sarbazSiah || selected.pieces == Pieces.sarbazSefid){
                        sarbaz1Siah = false;
                    }
                        break;
                   // }

                }
            }
            Alert alert=new Alert(Alert.AlertType.INFORMATION,"jaye monasebi ra choose nakardi  :/ !");
            alert.show();

        } else {
            if (Main.gameMenu.getCell(x, y).pieces != Pieces.khali) {
                Main.gameMenu.setSelectedCell(Main.gameMenu.getCell(x, y));
                Main.gameMenu.setSelected(true);
                switch (Main.gameMenu.getCell(x, y).pieces) {


                    case rokhSefid:
                    case rokhSiah:
                        for (int i = 0; i < 8; i++) {
                            if (i != y) {
                                if (Main.gameMenu.getCell(i, y).pieces == Pieces.khali) {
                                    Main.gameMenu.getCell(i, y).getRectangle().setFill(Color.LIGHTCYAN);
                                    Main.gameMenu.getValidCells().add(new Pair<>(i, y));
                                } else {
                                    Main.gameMenu.getCell(i, y).getRectangle().setFill(Color.RED);
                                    Main.gameMenu.getValidCells().add(new Pair<>(i, y));

                                }
                            }
                        }


                        for (int i = 0; i < 8; i++) {
                            if (i != y) {
                                if (Main.gameMenu.getCell(x, i).pieces == Pieces.khali) {
                                    Main.gameMenu.getCell(x, i).getRectangle().setFill(Color.CYAN);
                                    Main.gameMenu.getValidCells().add(new Pair<>(x, i));
                                } else {
                                    Main.gameMenu.getCell(x, i).getRectangle().setFill(Color.RED);
                                    Main.gameMenu.getValidCells().add(new Pair<>(x, i));
                                }
                            }
                        }
                        break;

                    case fillSiah:
                    case fillSefid:



                        for (int i = 0 ; i < 8 ; i++){
                            for (int j = 0 ; j < 8 ; j++){
                                if(Math.abs(x-i)==Math.abs(y-j) && x!=i){

                                    if (Main.gameMenu.getCell(i,j).pieces == Pieces.khali) {
                                        Main.gameMenu.getCell(i,j).getRectangle().setFill(Color.CYAN);
                                        Main.gameMenu.getValidCells().add(new Pair<>(i,j));
                                    } else {
                                        Main.gameMenu.getCell(i,j).getRectangle().setFill(Color.RED);
                                        Main.gameMenu.getValidCells().add(new Pair<>(i,j));
                                    }

                                }
                                    }
                                }

                        break;


                    case asbSefid:
                    case asbSiah:

                         /*
                        [0,0]
                        [1,2][2,1]
                        [2,-1][1,-2]
                        [-1,2][-2,1]
                        [-2,-1][-1,-2]
                         */


                        if(x-2>=0){
                            if (y+1<=7){
                                if(Main.gameMenu.getCell(x-2,y+1).pieces == Pieces.khali) {
                                    Main.gameMenu.getCell(x - 2, y + 1).getRectangle().setFill(Color.CYAN);
                                }
                                else {
                                    Main.gameMenu.getCell(x-2,y+1).getRectangle().setFill(Color.RED);
                                }
                                Main.gameMenu.getValidCells().add(new Pair<>(x - 2, y + 1));
                            }


                            if(y-1>=0){
                                if(Main.gameMenu.getCell(x-2,y-1).pieces == Pieces.khali) {
                                    Main.gameMenu.getCell(x - 2, y - 1).getRectangle().setFill(Color.CYAN);
                                }
                                else{
                                    Main.gameMenu.getCell(x-2,y-1).getRectangle().setFill(Color.RED);

                                }
                                Main.gameMenu.getValidCells().add(new Pair<>(x - 2, y - 1));
                            }

                        }
                        if(x-1>=0){
                            if (y+2<=7){
                                if(Main.gameMenu.getCell(x-1,y+2).pieces == Pieces.khali) {
                                    Main.gameMenu.getCell(x - 1, y +2).getRectangle().setFill(Color.CYAN);
                                }
                                else{
                                    Main.gameMenu.getCell(x-1,y+2).getRectangle().setFill(Color.RED);

                                }
                                Main.gameMenu.getValidCells().add(new Pair<>(x - 1, y +2));

                            }
                            if(y-2>=0){
                                Main.gameMenu.getCell(x-1, y-2).getRectangle().setFill(Color.CYAN);
                                Main.gameMenu.getValidCells().add(new Pair<>(x-1, y-2));
                            }
                        }
                        if(x+2<=7){
                            if (y+1<=7){
                                Main.gameMenu.getCell(x+2, y+1).getRectangle().setFill(Color.CYAN);
                                Main.gameMenu.getValidCells().add(new Pair<>(x+2, y+1));
                            }
                            if(y-1>=0){
                                Main.gameMenu.getCell(x+2, y-1).getRectangle().setFill(Color.CYAN);
                                Main.gameMenu.getValidCells().add(new Pair<>(x+2, y-1));
                            }
                        }
                        if(x+1<=7){
                            if (y+2<=7){
                                Main.gameMenu.getCell(x+1, y+2).getRectangle().setFill(Color.CYAN);
                                Main.gameMenu.getValidCells().add(new Pair<>(x+1, y+2));
                            }
                            if(y-2>=0){
                                Main.gameMenu.getCell(x+1, y-2).getRectangle().setFill(Color.CYAN);
                                Main.gameMenu.getValidCells().add(new Pair<>(x+1, y-2));
                            }
                        }


                        break;







                    case shahSefid:
                    case shahSiah:
                        break;

                    case vazirSefid:
                    case vazirSiah:


                        for (int i = 0; i < 8; i++) {
                            if (i != y) {
                                if (Main.gameMenu.getCell(i, y).pieces == Pieces.khali) {
                                    Main.gameMenu.getCell(i, y).getRectangle().setFill(Color.LIGHTCYAN);
                                    Main.gameMenu.getValidCells().add(new Pair<>(i, y));
                                } else {
                                    Main.gameMenu.getCell(i, y).getRectangle().setFill(Color.RED);
                                    Main.gameMenu.getValidCells().add(new Pair<>(i, y));

                                }
                            }
                        }


                        for (int i = 0; i < 8; i++) {
                            if (i != y) {
                                if (Main.gameMenu.getCell(x, i).pieces == Pieces.khali) {
                                    Main.gameMenu.getCell(x, i).getRectangle().setFill(Color.CYAN);
                                    Main.gameMenu.getValidCells().add(new Pair<>(x, i));
                                } else {
                                    Main.gameMenu.getCell(x, i).getRectangle().setFill(Color.RED);
                                    Main.gameMenu.getValidCells().add(new Pair<>(x, i));
                                }
                            }
                        }

/////////

                        for (int i = 0 ; i < 8 ; i++){
                            for (int j = 0 ; j < 8 ; j++){
                                if(Math.abs(x-i)==Math.abs(y-j) && x!=i){

                                    if (Main.gameMenu.getCell(i,j).pieces == Pieces.khali) {
                                        Main.gameMenu.getCell(i,j).getRectangle().setFill(Color.CYAN);
                                        Main.gameMenu.getValidCells().add(new Pair<>(i,j));
                                    } else {
                                        Main.gameMenu.getCell(i,j).getRectangle().setFill(Color.RED);
                                        Main.gameMenu.getValidCells().add(new Pair<>(i,j));
                                    }

                                }
                            }
                        }

                        break;


                    case sarbazSefid:
                    case sarbazSiah:
                        if (sarbaz1Siah == true){
                            if (x-2>=0) {
                                Main.gameMenu.getCell(x - 2, y).getRectangle().setFill(Color.CYAN);
                                Main.gameMenu.getValidCells().add(new Pair<>(x-2,y));
                            }
                            if (x-1>=0) {
                                Main.gameMenu.getCell(x - 1, y).getRectangle().setFill(Color.CYAN);
                                Main.gameMenu.getValidCells().add(new Pair<>(x-1,y));
                            }
                        }
                        else{
                            Main.gameMenu.getCell(x-1,y).getRectangle().setFill(Color.CYAN);
                            Main.gameMenu.getValidCells().add(new Pair<>(x-1,y));
                        }


                        break;

                }

            }
        }
    }


    public void setImageView(ImageView imageView) {
        this.imageView = imageView;
    }

    public ImageView getImageView() {
        return imageView;
    }

    public   static void retunToHAlatAvalie() {

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if ((i + j) % 2 == 0) {
                    Main.gameMenu.getCell(i, j).rectangle.setFill(Color.WHITE);
                } else {
                    Main.gameMenu.getCell(i, j).rectangle.setFill(Color.BLACK);

                }
            }
        }
    }
}

