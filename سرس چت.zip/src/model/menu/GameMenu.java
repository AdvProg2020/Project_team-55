package model.menu;

import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.util.Pair;
import model.Cell;
import sample.Main;

import java.awt.*;
import java.io.FileNotFoundException;
import java.util.ArrayList;


public class GameMenu {

    Scene scene2;
    Pane pane2;
    FirstMenu firstMenu;
    Cell[][] cell;
    Rectangle[][] selector;
    Cell selectedCell;
    boolean selected = false;
   private ArrayList<Pair<Integer, Integer>> validCells = new ArrayList<>(); //araye az khanehaye maghsad


    public GameMenu() throws FileNotFoundException {

        Text one=new Text("1");
        one.relocate(130,530);

        Text two=new Text("2");
        two.relocate(130,480);

        Text three=new Text("3");
        three.relocate(130,430);

        Text four=new Text("4");
        four.relocate(130,380);

        Text five=new Text("5");
        five.relocate(130,330);


        Text six=new Text("6");
        six.relocate(130,280);

        Text sev=new Text("7");
        sev.relocate(130,230);

        Text eight=new Text("8");
        eight.relocate(130,180);



        Text a=new Text("A");
        a.relocate(170,130);

        Text b=new Text("B");
        b.relocate(220,130);

        Text c=new Text("C");
        c.relocate(270,130);

        Text d=new Text("D");
        d.relocate(320,130);

        Text e=new Text("E");
        e.relocate(370,130);

        Text f=new Text("F");
        f.relocate(420,130);

        Text g=new Text("G");
        g.relocate(470,130);

        Text h=new Text("H");
        h.relocate(520,130);






        this.pane2 = new Pane();
        this.scene2 = new Scene(pane2, 700, 700);
        cell = new Cell[8][8];
        selector = new Rectangle[8][8];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if ((i + j) % 2 == 0) {
                    cell[i][j] = new Cell(i, j, Color.WHITE);
                } else {
                    cell[i][j] = new Cell(i, j, Color.BLACK);
                }
                selector[i][j] = new Rectangle(50,50,Color.GREEN);
                selector[i][j].setOpacity(0);
                selector[i][j].relocate(150 + (50 * j), 150 + (50 * i));
                cell[i][j].getRectangle().relocate(150 + (50 * j), 150 + (50 * i));
                ImageView imageView = new ImageView();
                imageView.setFitHeight(25);
                imageView.setFitWidth(25);
                imageView.setX(150 + (50 * j));
                imageView.setY(150 + (50 * i));
                cell[i][j].setImageView(imageView);
                int x = i;
                int y = j;
                selector[i][j].addEventFilter(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent event) {
                        Cell.handleEventForThisCell(x,y);
                    }
                });
                pane2.getChildren().addAll(cell[i][j].getRectangle(), cell[i][j].getImageView(),selector[i][j]);

            }
        }
        Cell.assignCells(cell);

        pane2.getChildren().addAll(one,two,three,five,four,sev,six,eight,a,b,c,d,e,f,g,h);

        Button  logout=new Button("Log Out");
        logout.relocate(600,500);
        pane2.getChildren().add(logout);
        logout.addEventFilter(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                Main.stage.setScene(Main.firstMenu.getScene());
                Alert alert= new Alert(Alert.AlertType.INFORMATION,"You give up ♥");
                alert.show();
            }
        });

    }


    public void handleGameMenu() {

    }

    public Cell getCell(int x, int y) {
        return cell[x][y];
    }

    public void setSelectedCell(Cell selectedCell) {
        this.selectedCell = selectedCell;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public Cell getSelectedCell() {
        return selectedCell;
    }

    public boolean getSelected() {
        return selected;
    }

    public ArrayList<Pair<Integer, Integer>> getValidCells() {
        return validCells;
    }

    public void setValidCells(ArrayList<Pair<Integer, Integer>> validCells) {
        this.validCells = validCells;
    }

}
