package model.menu;

import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.media.Media;
import javafx.stage.Stage;
import model.Account;
import sample.Main;

import java.io.FileNotFoundException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class FirstMenu {
    Stage stage;
    Scene scene;
    Pane pane;
    Button register;
    Button login;
    TextField userName;
    TextField passWord;


    Button deletAccount = new Button("delet Account");
    Button changePass = new Button("change Pass");
    Button logOut = new Button("log Out");
    Button goPlay = new Button("go and game");
    Button ok=new Button("Ok");
   private Account account;
   private Boolean varedShode = false;

    public void setVaredShode(Boolean varedShode) {
        this.varedShode = varedShode;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public FirstMenu(Stage stage) {
        this.stage=stage;
        Pane pane = new Pane();
        Scene scene = new Scene(pane, 700, 700);
        create(scene, pane, this);
        this.scene = scene;
        this.pane = pane;

    }

    public Scene getScene() {
        return scene;
    }

    public void handleLogin() {
        deletAccount.relocate(400, 100);
        changePass.relocate(400, 150);
        logOut.relocate(400, 200);
        goPlay.relocate(400, 250);
        pane.getChildren().addAll(deletAccount, changePass, logOut, goPlay);

        goPlay.addEventFilter(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                GameMenu gameMenu= null;
                try {
                    gameMenu = new GameMenu();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                Main.gameMenu=gameMenu;
               stage.setScene(gameMenu.scene2);
            }
        });


        deletAccount.addEventFilter(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                Account.allAccounts.remove(account);
                Alert alert=new Alert(Alert.AlertType.CONFIRMATION,"your account was deleted !");
                alert.show();
                pane.getChildren().removeAll(logOut,changePass,deletAccount,goPlay);
            }
        });


        changePass.addEventFilter(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                TextField changePass = new TextField("change Password");
                changePass.relocate(30,50);
                ok.relocate(80,70);
                pane.getChildren().addAll(changePass,ok);
                changePass.addEventFilter(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent event) {
                        changePass.clear();
                    }
                });
                ok.addEventFilter(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent event) {

                        String newPass = changePass.getText();
                        String olgo = ("(\\w)+");
                        Pattern pattern = Pattern.compile(olgo);
                        Matcher matcher = pattern.matcher(newPass);

                        if (matcher.matches()) {
                            Alert alert = new Alert(Alert.AlertType.INFORMATION, " your password change .");
                            alert.show();
                            account.setPassword(newPass);
                            pane.getChildren().removeAll(ok,changePass);
                        } else {
                            Alert alert = new Alert(Alert.AlertType.ERROR, " password format is invalid .");
                            alert.show();
                        }

                    }
                });

            }
        });

        logOut.addEventFilter(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
            varedShode=false;
            pane.getChildren().removeAll(deletAccount,changePass,logOut,goPlay);
            Account.allAccounts.add(account);
            account=null;
            }
        });

    }


    public void create(Scene scene, Pane pane, FirstMenu first) {



        TextField userName = new TextField("UserName");
        userName.relocate(100, 300);
        userName.addEventFilter(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                userName.clear();

            }
        });
        first.userName = userName;

        TextField passWord = new TextField("PassWord");
        passWord.relocate(100, 350);
        passWord.addEventFilter(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                passWord.clear();
            }
        });
        first.passWord = passWord;

        Button register = new Button("Register");
        register.relocate(100, 450);

        register.addEventFilter(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                String username = userName.getText();
                String password = passWord.getText();
                Account.checkRegister(username, password);
            }
        });
        this.register = register;

        Button login = new Button("Login");
        login.relocate(100, 400);
        login.addEventFilter(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                String username = userName.getText();
                String password = passWord.getText();
                Account.checkLogin(username, password);

            }
        });

        this.login = login;

        pane.getChildren().addAll(login, passWord, register, userName);

    }


}
