package model;

public enum Pieces {
    rokhSefid,fillSefid,asbSefid,shahSefid,vazirSefid,sarbazSefid,
    khali,
    rokhSiah,fillSiah,asbSiah,shahSiah,vazirSiah,sarbazSiah;
}
