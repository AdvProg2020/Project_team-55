package model;

import javafx.scene.control.Alert;
import sample.Main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Account {


    static String olgo = ("(\\w)+");
    public static ArrayList<Account> allAccounts = new ArrayList<>();
    public static HashMap<String, String> userAndPassword = new HashMap();
    private String name;
    private String password;

    public Account(String name, String password) {
        this.name = name;
        this.password = password;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


    public static void checkRegister(String username, String password) {
        int counter1 = 0;
        int counter2 = 0;
        Pattern pattern = Pattern.compile(olgo);
        Matcher matcher = pattern.matcher(username);
        if (matcher.matches()) {
            if ((userAndPassword.keySet().contains(matcher.group())) == false) {
                counter1++;
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR, "a user exists with this username.");
                alert.show();
            }

        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR, "username format is invalid.");
            alert.show();
        }

        Pattern pattern2 = Pattern.compile(olgo);
        Matcher matcher2 = pattern2.matcher(password); //password
        if (matcher2.matches()) {
            counter2++;
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR, "password format is invalid");
            alert.show();
        }
        if (counter1 == 1 && counter2 == 1) {
//            userAndPassword.keySet().add(matcher.group());
//            userAndPassword.values().add(matcher2.group());
            Account account = new Account(username, password);
            allAccounts.add(account);
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "register successful");
            for (Account a : allAccounts) {
                System.out.println(a.name);
            }
            alert.show();
        }
    }
    public static void
    checkLogin(String username, String password) {

        int counter1 = 0;
        int counter2 = 0;

        Pattern pattern = Pattern.compile(olgo);
        Matcher matcher = pattern.matcher(username);

        Pattern pattern2 = Pattern.compile(olgo);
        Matcher matcher2 = pattern2.matcher(password);

        if (matcher.matches()) {
            for (Account searchingUser : allAccounts) {
                if (searchingUser.name.equals(matcher.group())) {
                    counter1++;
                    if (matcher2.matches()) {
                        if(!searchingUser.password.equals(matcher2.group()) ) {
                            Alert alert = new Alert(Alert.AlertType.ERROR, "incorrect password");
                            alert.show();

                        }else {counter2++;}
                    }else {
                        Alert alert = new Alert(Alert.AlertType.ERROR, "password format is invalid");
                        alert.show();
                    }
                    } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR, "no user exists with this username");
                    alert.show();

                }
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR, "username format is invalid");
            alert.show();

        }

        if (counter1 == 1 && counter2 == 1) {
         int counter3=0;
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "login successful");
            alert.show();
            Main.firstMenu.setVaredShode(true);
            for(Account  searching: allAccounts){
                if(searching.name.equals(username)){
                   break;
                }counter3++;
            }
            Main.firstMenu.setAccount(allAccounts.get(counter3));
            allAccounts.remove(counter3);
            Main.firstMenu.handleLogin();
        }
    }


}