package sample;

import javafx.application.Application;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import model.Account;
import model.menu.FirstMenu;
import model.menu.GameMenu;

import java.io.File;


public class Main extends Application {
public  static  FirstMenu firstMenu;
public static GameMenu gameMenu;
static public  Stage stage;


    @Override
    public void start(Stage primaryStage) throws Exception{
        this.stage=primaryStage;
        primaryStage.setTitle("Chess");
        firstMenu=new FirstMenu(stage);
        primaryStage.setScene(firstMenu.getScene());

        String path = "C:\\Users\\Asus\\IdeaProjects\\shatranj\\src\\model\\02 DADE.mp3";
        Media media = new Media(new File(path).toURI().toString());
        MediaPlayer mediaPlayer = new MediaPlayer(media);
        mediaPlayer.setAutoPlay(true);
        primaryStage.setTitle("Playing Audio");
        primaryStage.show();

    }

    public static void main(String[] args) {
        launch(args);
    }
}
