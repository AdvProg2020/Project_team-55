

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

public class IntroToAnimation extends Application {
    public static void main(String[] args) {
        launch(args);
    }

   final static javafx.scene.image.Image abi= new javafx.scene.image.Image(IntroToAnimation.class.getResource("abi.jpg").toString());
    final static javafx.scene.image.Image banafsh= new javafx.scene.image.Image(IntroToAnimation.class.getResource("banafsh.jpg").toString());
    final static javafx.scene.image.Image ghermez= new javafx.scene.image.Image(IntroToAnimation.class.getResource("ghermez.jpg").toString());
    final static javafx.scene.image.Image narenji= new javafx.scene.image.Image(IntroToAnimation.class.getResource("narenji.jpg").toString());
    final static javafx.scene.image.Image sabz= new javafx.scene.image.Image(IntroToAnimation.class.getResource("sabz.jpg").toString());
    final static javafx.scene.image.Image zard= new javafx.scene.image.Image(IntroToAnimation.class.getResource("zard.jpg").toString());


    private Group ghalbs;


    @Override
    public void start(Stage primaryStage) throws Exception{

     final ImageView abiImageView=new ImageView(abi);
        final ImageView banafshImageView=new ImageView(banafsh);
        final ImageView ghermezImageView=new ImageView(ghermez);
        final ImageView narenjiImageView=new ImageView(narenji);
        final ImageView sabzImageView=new ImageView(sabz);
        final ImageView zardImageView=new ImageView(zard);



        ghalbs=new Group(abiImageView);
        ghalbs.setTranslateX(200);
        ghalbs.setTranslateY(222);

        Timeline t=new Timeline();
        t.setCycleCount(Timeline.INDEFINITE);




        t.getKeyFrames().add(new KeyFrame(
                Duration.millis(100),
                (ActionEvent event)-> {
                    ghalbs.getChildren().setAll(ghermezImageView);
                }
        ));



        t.getKeyFrames().add(new KeyFrame(
                Duration.millis(200),
                (ActionEvent event)-> {
                    ghalbs.getChildren().setAll(narenjiImageView);
                }
        ));




        t.getKeyFrames().add(new KeyFrame(
                Duration.millis(300),
                (ActionEvent event)-> {
                    ghalbs.getChildren().setAll(zardImageView);
                }
        ));


        t.getKeyFrames().add(new KeyFrame(
                Duration.millis(400),
                (ActionEvent event)-> {
                    ghalbs.getChildren().setAll(sabzImageView);
                }
        ));


        t.getKeyFrames().add(new KeyFrame(
                Duration.millis(500),
                (ActionEvent event)-> {
                    ghalbs.getChildren().setAll(abiImageView);
                }
        ));



        t.getKeyFrames().add(new KeyFrame(
                Duration.millis(600),
                (ActionEvent event)-> {
                    ghalbs.getChildren().setAll(banafshImageView);
                }
        ));

        t.play();
        primaryStage.setScene(new Scene(ghalbs,600,400));
        primaryStage.show();


    }



}
