package org.example;

import Model.DataLoader;
import Model.DataSaver;
import Model.ExitThread;
import Model.Manager;
import com.google.gson.internal.$Gson$Preconditions;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ScrollPane;
//import javafx.scene.media.Media;
//import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import org.menu.MainPage;
import org.menu.SellerPanel;

import javax.print.attribute.standard.Media;
import java.io.*;
import java.net.Socket;
import java.util.Optional;

public class App extends Application {

    private static Scene scene;
    private static Stage mainStage;
   private static  ObjectInputStream objectInputStream;

    public static ObjectInputStream getObjectInputStream() {
        return objectInputStream;
    }

    public static void setObjectInputStream(ObjectInputStream objectInputStream) {
        App.objectInputStream = objectInputStream;
    }

    private static Socket socket;
   private static DataOutputStream dataOutputStream;
   private static DataInputStream dataInputStream;
   private  static boolean signedIn;

    public App() throws IOException {
    }

    public static boolean isSignedIn() {
        return signedIn;
    }

    public static void setSignedIn(boolean signedIn) {
        App.signedIn = signedIn;
    }

    @Override
    public void start(Stage stage) throws IOException, ClassNotFoundException {




        mainStage = stage;
        mainStage.setMaximized(true);
        mainStage.setWidth(1500);
        mainStage.setHeight(900);
        mainStage.setMinHeight(500);
        mainStage.setMinWidth(500);

//        String path = "E:\\java projects\\graphic phase\\src\\main\\resources\\Pachelbel - Canon in D (Best Piano Version).mp3";
//        Media media = new Media(new File(path).toURI().toString());
//        MediaPlayer mediaPlayer = new MediaPlayer(media);
//        mediaPlayer.setAutoPlay(true);

        Runtime runtime=Runtime.getRuntime();
        runtime.addShutdownHook(new ExitThread());

        mainStage.setOnCloseRequest(event -> {
            event.consume();
            closeProgram();
        });

try{
    DataLoader.readData();
    mainStage.show();
}catch (Exception e){
    System.out.println("error");
}

    }



    public static void main(String[] args) throws IOException {

        socket=new Socket("localhost",1234);


        dataInputStream=new DataInputStream(new BufferedInputStream(socket.getInputStream()));
        dataOutputStream=new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));
        objectInputStream=new ObjectInputStream(socket.getInputStream());
        launch(args);


    }

    public static DataOutputStream getDataOutputStream() {
        return dataOutputStream;
    }

    public static DataInputStream getDataInputStream() {
        return dataInputStream;
    }

    public static Stage getMainStage() {
        return mainStage;
    }

    public void closeProgram(){
        Alert exit=new Alert(Alert.AlertType.CONFIRMATION,"are you sure you want to exit?");
        exit.setTitle("exit");

        Optional<ButtonType> result=exit.showAndWait();

        if (result.get()==ButtonType.OK){
            mainStage.close();
//            try {
//                if (Manager.getMainManager() != null) {
//                    DataSaver.saveData();
//                }
//            }catch (IOException e){
//                e.printStackTrace();
//            }
        }
    }
}