package org.menu;

import Model.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import org.example.App;

import java.io.IOException;
import java.util.Optional;

public abstract class Menu extends Scene {
    protected ScrollPane stagePane;
    protected AnchorPane pane;
    protected VBox wholeContent=new VBox();
    protected Label label = new Label();
    protected HBox navbar=new HBox();

    protected Object object;
    protected Scene previousPage;

    public Menu(ScrollPane root) throws IOException, ClassNotFoundException {
        super(root);
        pane = new AnchorPane();
        this.stagePane = root;
        manifestNavbar();
        init();
        stagePane.setFitToWidth(true);
        stagePane.setFitToHeight(true);
        stagePane.setContent(wholeContent);
        wholeContent.setSpacing(5);
        wholeContent.getChildren().addAll(navbar,pane);
        getStylesheets().add("userPanel.css");
        wholeContent.getStyleClass().add("pane");
    }

    public Menu(ScrollPane root, Object object ,Scene previousScene) throws IOException, ClassNotFoundException {
        super(root);
        pane = new AnchorPane();
        this.stagePane = root;
        manifestNavbar();
        this.object=object;
        this.previousPage=previousScene;
        init();
        stagePane.setFitToWidth(true);
        stagePane.setFitToHeight(true);
        stagePane.setContent(wholeContent);
        wholeContent.setSpacing(5);
        wholeContent.getChildren().addAll(navbar,pane);
        getStylesheets().add("userPanel.css");
        wholeContent.getStyleClass().add("pane");
    }

    public abstract void init() throws IOException, ClassNotFoundException;

    public void manifestNavbar() throws IOException, ClassNotFoundException {


        App.getDataOutputStream().writeUTF("get active user");
        App.getDataOutputStream().flush();
        User user=(User)App.getObjectInputStream().readObject();

        navbar.getChildren().clear();
        navbar.setMinHeight(50);
        navbar.getChildren();

        Button mainPage=new Button("main page");
        mainPage.setFont(Font.font("CHILLER",FontWeight.NORMAL,FontPosture.REGULAR,22));
        mainPage.setOnAction(event -> {
            try {
                App.getMainStage().setScene(new MainPage(new ScrollPane()));
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        });

        Button login=new Button("login");
        login.setFont(Font.font("CHILLER", FontWeight.BOLD, FontPosture.REGULAR,22));
        login.setOnAction(event -> {
            try {
                App.getMainStage().setScene(new LoginPanel(new ScrollPane(),(Menu)App.getMainStage().getScene()));
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        });

        Button signUp=new Button("sign up");
        signUp.setFont(Font.font("CHILLER",FontWeight.BOLD,FontPosture.REGULAR,22));
        signUp.setOnAction(event -> {
            try {
                App.getMainStage().setScene(new RegisterMenu(new ScrollPane(), (Menu) App.getMainStage().getScene()));
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        });

        Button logout=new Button("log out");
        logout.setFont(Font.font("CHILLER",FontWeight.NORMAL,FontPosture.REGULAR,22));
        logout.setOnAction(event -> {
            Alert alert=new Alert(Alert.AlertType.CONFIRMATION,"are you sure you want to log out?");
            Optional<ButtonType> result=alert.showAndWait();

            if (result.get()==ButtonType.OK){
                App.setSignedIn(false);
                try {
                    App.getDataOutputStream().writeUTF("log out");
                    App.getDataOutputStream().flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    App.getMainStage().setScene(new MainPage(new ScrollPane()));
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }
        });

        Button userPanel=new Button("user panel");
        userPanel.setFont(Font.font("CHILLER",FontWeight.NORMAL,FontPosture.REGULAR,22));
        userPanel.setOnAction(event -> {
            if (user instanceof Buyer){
                try {
                    App.getMainStage().setScene(new BuyerPanel(new ScrollPane()));
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }else if (user instanceof Seller){
                try {
                    App.getMainStage().setScene(new SellerPanel(new ScrollPane()));
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }else if (user instanceof Manager){
                try {
                    App.getMainStage().setScene(new ManagerPanel(new ScrollPane()));
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }
                }
        );

        Button product=new Button("product page");
        product.setFont(Font.font("CHILLER",FontWeight.NORMAL,FontPosture.REGULAR,22));
        product.setOnAction(event -> {
            try {
                App.getMainStage().setScene(new ProductMenu(new ScrollPane()));
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        });

        Button off=new Button("off page");
        off.setFont(Font.font("CHILLER",FontWeight.NORMAL,FontPosture.REGULAR,22));
        off.setOnAction(event -> {
            try {
                App.getMainStage().setScene(new OffMenu(new ScrollPane()));
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        });

        navbar.getChildren().add(mainPage);

        if (!App.isSignedIn()){
            navbar.getChildren().addAll(signUp,login);
        }else {
            navbar.getChildren().addAll(userPanel,logout);
        }

        navbar.getChildren().addAll(product,off);
        navbar.getStyleClass().add("navbar");
        navbar.setPrefWidth(App.getMainStage().getWidth());
        navbar.setSpacing(7);
    }
}
