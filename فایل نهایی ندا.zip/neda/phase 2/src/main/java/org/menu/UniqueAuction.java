package org.menu;

import Model.*;
import javafx.collections.FXCollections;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import org.example.App;

import java.io.IOException;
import java.util.ArrayList;

public class UniqueAuction extends  Menu{
    
    public UniqueAuction(ScrollPane root) throws IOException, ClassNotFoundException {
        super(root);
    }

    @Override
    public void init() throws IOException, ClassNotFoundException {
        Auction auction= (Auction) object;
        Product product=auction.getProduct();


        App.getDataOutputStream().writeUTF("get active user");
        App.getDataOutputStream().flush();
User user= (User) App.getObjectInputStream().readObject();

        VBox content=new VBox();


        Button back=new Button("return");
        back.setOnAction(event -> App.getMainStage().setScene(previousPage));
        content.getChildren().add(back);

        GridPane header=new GridPane();
        header.add(product.getPicture(),0,0);
        header.add(new Text(product.getName()),0,1);
        header.add(new Text("category: "+product.getCategory().getName()),0,2);



        header.add(new Text(product.getBrand()),1,0);
        header.add(new Text("score: "+product.getAverageScore()),1,2);


        content.getChildren().add(header);
        content.getChildren().add(new Text(product.getExplanation()));

        ListView<String> info=new ListView<>();

        for (String attribute:product.getSpecialAttributes().keySet()){
            info.getItems().add(attribute+": "+product.getSpecialAttributes().get(attribute));
        }

        content.getChildren().add(info);

        VBox comment=new VBox();


        content.getChildren().add(comment);

        TableView<Comment> commentTable=new TableView<>();
        commentTable.setItems(FXCollections.observableArrayList(product.getComments()));

        TableColumn<Comment, String> userColumn=new TableColumn<>("sender");
        userColumn.setCellValueFactory(new PropertyValueFactory<>("commenter"));

        TableColumn<Comment,String> messageColumn=new TableColumn<>("comment");
        messageColumn.setCellValueFactory(new PropertyValueFactory<>("message"));

        commentTable.getColumns().addAll(userColumn,messageColumn);

        content.getChildren().add(commentTable);


       content.getChildren().add(new Text("highest submited offer"+auction.getHighestProposal()));
       TextField offer=new TextField();
       offer.setPromptText("proposals ... ");
       if(auction.getProposal().containsKey(user)){
           offer.setText(""+auction.getProposal().get(user));
       }
       offer.textProperty().addListener(((observable, s, t1) -> {
           if(!t1.matches("\\d+"))
               offer.setText(s);
       }));

        Button submit=new Button("submit offer");
        submit.setOnAction(actionEvent -> {
            if (!offer.getText().isEmpty()){
                auction.getProposal().put((Buyer) user, Integer.parseInt(offer.getText()));
                new Alert(Alert.AlertType.INFORMATION,"your offer was successfully submitted").show();
            }else {
                new Alert(Alert.AlertType.ERROR,"no offer is entered").show();
            }
        });

        content.getChildren().addAll(offer,submit);



        TableView <Supporter> supporterTableView=new TableView<>();
        supporterTableView.setItems(FXCollections.observableArrayList(Supporter.getAllSupports()));

        TableColumn<Supporter, String> usernameColumn=new TableColumn<>("supporter");
        userColumn.setCellValueFactory(new PropertyValueFactory<>("username"));

        TableColumn<Supporter, String> logColumn=new TableColumn<>("logged in");
        logColumn.setCellValueFactory(new PropertyValueFactory<>("LoggedIn"));

        supporterTableView.getColumns().addAll(usernameColumn,logColumn);
        comment.getChildren().addAll(supporterTableView);

        //TODO CHATROOM



        pane.getChildren().add(content);


    }
}
