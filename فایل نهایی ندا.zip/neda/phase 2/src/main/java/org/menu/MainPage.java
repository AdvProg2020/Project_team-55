package org.menu;

import Model.Buyer;
import Model.Manager;
import Model.Seller;
import Model.User;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import org.example.App;

import java.io.IOException;

public class MainPage extends Menu{
    public MainPage(ScrollPane root) throws IOException, ClassNotFoundException {
        super(root);
    }



    @Override
    public void init() throws IOException, ClassNotFoundException {

        App.getDataOutputStream().writeUTF("get active user");
        App.getDataOutputStream().flush();
        User user=(User)App.getObjectInputStream().readObject();


        VBox navbar=new VBox();
        pane.getChildren().add(navbar);

        AnchorPane.setTopAnchor(navbar,200.0);
        AnchorPane.setLeftAnchor(navbar,200.0);


        Button login=new Button("login");
        login.setFont(Font.font("CHILLER", FontWeight.NORMAL, FontPosture.REGULAR,22));
        login.addEventFilter(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                try {
                    App.getMainStage().setScene(new LoginPanel(new ScrollPane(),(Menu)App.getMainStage().getScene()));
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }
        });

        Button register=new Button("register");
        register.setFont(Font.font("CHILLER",FontWeight.NORMAL,FontPosture.REGULAR,22));
        register.addEventFilter(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                RegisterMenu registerMenu= null;
                try {
                    registerMenu = new RegisterMenu(new ScrollPane(), (Menu) App.getMainStage().getScene());
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
                App.getMainStage().setScene(registerMenu);
            }
        });

        Button products=new Button("products");
        products.setFont(Font.font("CHILLER",FontWeight.NORMAL,FontPosture.REGULAR,22));
        products.setOnAction(event -> {
            try {
                App.getMainStage().setScene(new ProductMenu(new ScrollPane()));
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        });

        Button offs=new Button("offs");
        offs.setFont(Font.font("CHILLER",FontWeight.NORMAL,FontPosture.REGULAR,22));
        offs.setOnAction(event -> {
            try {
                App.getMainStage().setScene(new OffMenu(new ScrollPane()));
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        });

        Button panel=new Button("userPanel");
        panel.setFont(Font.font("CHILLER",FontWeight.NORMAL,FontPosture.REGULAR,22));
        panel.setOnAction(event -> {
            if (user instanceof Buyer){
                try {
                    App.getMainStage().setScene(new BuyerPanel(new ScrollPane()));
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }else if (user instanceof Seller){
                try {
                    App.getMainStage().setScene(new SellerPanel(new ScrollPane()));
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }else if (user instanceof Manager){
                try {
                    App.getMainStage().setScene(new ManagerPanel(new ScrollPane()));
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }
        });

        if (!App.isSignedIn()){
            navbar.getChildren().addAll(login,register);
        }else {
            navbar.getChildren().add(panel);
        }


        navbar.getChildren().addAll(products,offs);
        navbar.setSpacing(10);
    }
}
