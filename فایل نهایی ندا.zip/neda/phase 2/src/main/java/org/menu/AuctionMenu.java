package org.menu;

import Model.Auction;
import Model.Product;
import javafx.collections.FXCollections;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import javax.swing.*;
import java.io.IOException;

public class AuctionMenu extends  Menu{


    public AuctionMenu(ScrollPane root) throws IOException, ClassNotFoundException {
        super(root);
    }

    @Override
    public void init() {

        TableView <Auction> auctionTable=new TableView<>();
        auctionTable.setItems(FXCollections.observableArrayList(Auction.getAllAuction()));

        TableColumn<Auction, Product>productColumn =new TableColumn<>("product");
        productColumn.setCellValueFactory(new PropertyValueFactory<>("product"));


        TableColumn<Auction, Product> highestColumn =new TableColumn<>("highest proposal");
        highestColumn.setCellValueFactory(new PropertyValueFactory<>("highest proposal"));

        auctionTable.getColumns().addAll(productColumn,highestColumn);

        pane.getChildren().add(auctionTable);


    }




}
