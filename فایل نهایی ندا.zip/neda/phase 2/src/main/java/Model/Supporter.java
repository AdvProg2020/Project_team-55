package Model;

import java.util.LinkedList;

public class Supporter extends User{
    public static LinkedList<Supporter>allSupports=new LinkedList<>();
    private boolean logedInSupporter;

    public static LinkedList<Supporter> getAllSupports() {
        return allSupports;
    }

    public static void setAllSupports(LinkedList<Supporter> allSupports) {
        Supporter.allSupports = allSupports;
    }

    public Supporter(String userName, String firstName, String lastName, String email, String phoneNumber, String password, String profile) {
        super(userName, firstName, lastName, email, phoneNumber, password, profile);
        allSupports.add(this);


    }

    @Override
    public void changeInfo(String field, String newValue) {

    }

    public boolean isLogedInSupporter() {
        return logedInSupporter;
    }


    public void setLogedInSupporter(boolean logedInSupporter) {
        this.logedInSupporter = logedInSupporter;
    }
}
