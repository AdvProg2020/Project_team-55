package Model;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public abstract class Request {
    public static ArrayList<Request> allRequests = new ArrayList<Request>();
    protected String id;
    protected Seller sender;
    protected LocalDateTime dateTime;

    public static ArrayList<Request> getAllRequests() {
        return allRequests;
    }

    public static Request getRequestsById(String id) {
        for (Request request : allRequests) {
            if (request.id.equals(id)) {
                return request;
            }
        }
        return null;
    }

    public void showDetails() {

    }

    public void downloadFile(FileProducts fileProducts) throws IOException {
        OutputStream outputStream = new FileOutputStream("C:/Downloads/"+String.valueOf(fileProducts));
        for (int bytes : fileProducts.getFileBytes()) {
            outputStream.write(bytes);
        }
    }


    public abstract void acceptRequest();

    public abstract void declineRequest();

    public String getDateTime() {
        return dateTime.format(DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss"));
    }

    public Seller getSender() {
        return sender;
    }

    public String getId() {
        return id;
    }

    public String getType() {
        return getClass().getSimpleName();
    }
}
