package Model;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.LinkedList;

public class FileProducts extends Product{
    LinkedList<Integer> fileByte=new LinkedList<>();
   private String fileNAMe;

    public FileProducts(String productId, float price, Category category, HashMap<String, String> specialAttributes, String explanation, Seller seller, String picture , String entry ) throws IOException {
        super(productId, price, category, specialAttributes, explanation, seller, picture);
        getByte(entry);
        this.fileNAMe=entry.substring(entry.lastIndexOf("/"));
    }

    public String getFileNAMe() {
        return fileNAMe;
    }

    public LinkedList<Integer> getFileBytes(){
return fileByte;
    }

    public void setFileBytes(  LinkedList<Integer> fileBytes){
this.fileByte=fileBytes;
    }


    public void getByte(String entry) throws IOException {
        InputStream inputStream=new FileInputStream(entry);
        int nextByte;
        while ((nextByte=inputStream.read())!=-1){
            fileByte.add(nextByte);
        }
    }



}
