package Model;

public class Message {

    String messageText;
    private User sender;
    private User receiver;


    public Message(String messageText, User sender, User receiver) {
        this.messageText = messageText;
        this.sender = sender;
        this.receiver = receiver;
    }
}
