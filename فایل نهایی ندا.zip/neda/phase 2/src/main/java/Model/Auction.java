package Model;

//import com.sun.deploy.config.Config;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;

public class Auction {
    private HashMap<Buyer,Integer> proposal=new HashMap<>();
    private LocalDateTime startDate;
    private LocalDateTime stopDate;
    private Product product;
    private static ArrayList<Auction>allAuction=new ArrayList();


    public Auction( LocalDateTime startDate, LocalDateTime stopDate, Product product) {
        this.proposal = proposal;
        this.startDate = startDate;
        this.stopDate = stopDate;
        this.product = product;
        allAuction.add(this);
    }

    public static ArrayList<Auction> getAllAuction() {
        return allAuction;
    }

    public HashMap<Buyer, Integer> getProposal() {
        return proposal;
    }

    public void setProposal(HashMap<Buyer, Integer> proposal) {
        this.proposal = proposal;
    }

    public LocalDateTime getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDateTime startDate) {
        this.startDate = startDate;
    }

    public LocalDateTime getStopDate() {
        return stopDate;
    }

    public void setStopDate(LocalDateTime stopDate) {
        this.stopDate = stopDate;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }


    public int getHighestProposal(){

        int highest=proposal.get(0);
        for (int proposal:proposal.values()){
            if (proposal>highest){
                highest=proposal;
            }
        }
        return highest;
    }


}
